<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Форма</title>
<style type="text/css">
.error{ font-weight: bold;
color: #C00123;}
</style>
</head>
<body>
<?php
if(!empty($_REQUEST['name'])){
	$name=$_REQUEST['name'];
}else{
	$name=NULL;
	echo '<p class="error"> Забравили сте да въведете вашето име!</p>';
}
if(!empty($_REQUEST['email'])){
	$email=$_REQUEST['email'];
}else{
	$email=NULL;
	echo '<p class="error"> Забравили сте да въведете вашият имейл адрес!</p>';
}
if(isset($_REQUEST['gender'])){
	$gender=$_REQUEST['gender'];
	if($gender=="M"){
		$greeting='<p><strong>Добър ден господине!</strong></p>';
	}elseif($gender=="F"){
		$greeting='<p><strong>Добър ден госпожо!</strong></p>';
	}else{
		echo '<p class="error">Вашият пол не е коректен!</p>';
	}else{
		$gender=NULL;
		echo '<p class="error">Полът ви не е избран!</p>';
	}
if($name&&$email&&$gender&&$comments){
	echo "<p>Благодарим Ви, <strong> $name </strong>, за оставения комeнтар:</p>
	<pre>$comments</pre> 
	<p>Ние ще Ви отговорим на следния адрес: <em> $email </em>.</p>\n";
	echo $greeting;
}else{
	echo '<p class="error">Моля, върнете се да попълнете формата отново!</p>';
}
?>
</body>
</html>
