<!DOCTYPE html>
<html>
<head>
<title>Въведена инаформация</title>
<meta charset="utf-8">
</head>
<body>
<?php
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$comments=$_REQUEST['comments'];
//isset() - функция проверяваща дали една променлива има стойност различна от NULL
if(isset($_REQUEST['gender'])){
	$gender=$_REQUEST['gender'];
}else{
	$gender=NULL;
}
if($gender=="M"){
	echo "<p><strong>Добър ден господин $name!</strong></p>";
}elseif($gender=="F"){
	echo "<p><strong>Добър ден госпожо $name!</strong></p>";
}else{
	echo '<p><strong><big>Забравихте да изберете своя пол!</big></strong></p>';
}
	
	
	
echo "<p>Благодарим Ви за оставения комeнтар:</p>
	<pre>$comments</pre> 
	<p>Ние ще Ви отговорим на следния адрес: <em> $email </em>.</p>\n";

?>
</body>
</html>