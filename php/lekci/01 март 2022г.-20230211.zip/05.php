<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
.error{ color:#FF0000;}
</style>
<title>Регистрационна форма</title>
</head>
<body>
<?php
$username=$email=$gender=$datta=$comment=$passw="";
$usernameEr=$emailEr=$genderEr=$dattaEr=$passwEr="";
if($_SERVER['REQUEST_METHOD']=="POST"){
	if(empty($_POST['username'])){
		$usernameEr="Потребителското име е задължително!";
	}else{
		$username=test_input($_POST['username']);
	}
	
	if(empty($_POST['passw'])){
		$passwEr="Паролата е задължителна!";
	}else{
		$passw=test_input($_POST['passw']);
	}
	
	if(empty($_POST['email'])){
		$emailEr="Имейл адреса е задължителен!";
	}else{
		$email=test_input($_POST['email']);
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			$emailEr="Невалиден емайл формат.";
		}
	}
	
	if(empty($_POST['datta'])){
		$dattaEr="";
	}else{
		$datta=test_input($_POST['datta']);
	}
	
	if(empty($_POST['comment'])){
		$comment="";
	}else{
		$comment=test_input($_POST['comment']);
	}
	
	if(empty($_POST['gender'])){
		$genderEr="Изисква се да изберете пол!";
	}else{
		$gender=test_input($_POST['gender']);
	}
}

function test_input($data){
	$data=trim($data);
	$data=stripslashes($data);
	$data=htmlspecialchars($data);
	return $data;
}
?>
<h2>Регистрационна бланка</h2>
<p><span class="error">* задължително поле</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
<table>
<tr>
<td>Потребителско име:</td>
<td><input type="text" name="username">
	<span class="error">*<?php echo $usernameEr; ?></span></td>
</tr>
<tr>
<td>Парола:</td>
<td><input type="password" name="passw">
	<span class="error">*<?php echo $passwEr; ?></span></td>
</tr>
<tr>
<td>Имейл адрес:</td>
<td><input type="text" name="email">
	<span class="error">*<?php echo $emailEr; ?></span></td>
</tr>
<tr>
<td>Дата на регистрация:</td>
<td><input type="date" name="datta">
	<span class="error"><?php echo $dattaEr;?> </span></td>
</tr>
<tr>
<td>Допълнителна информация:</td>
<td><textarea name="comment" rows="5" cols="40"></textarea></td>
</tr>
<tr>
<td>Изберете пол:</td>
<td><input type="radio" name="gender" value="male">Мъж<br>
	<input type="radio" name="gender" value="female">Жена<br>
	<span class="error">*<?php echo $genderEr; ?></span></td>
</tr>
</table>
<input type="submit" name="submit" value="РЕГИСТРИРАЙ">
</form>
<?php
echo "<br><br>";
echo "<h2>Данните на регистрацият потребител са:</h2>";
echo "Потребителско име: $username <br>";
echo "Парола: $passw <br>";
echo "Имейл адрес: $email <br>";
echo "Дата на регистрация: $datta <br>";
echo "Допълнителна информация: $comment <br>";
echo "Пол: $gender";
?>
</body>
</html>