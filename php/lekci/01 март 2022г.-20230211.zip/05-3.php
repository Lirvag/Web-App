<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>HTML Формуляр</title>
<style>
label {font-weight: Bold;
color:#300ACC;}
</style>
</head>
<body>
<form method="post" action="05-2.php">
<fieldset>
<legend>
Въведете нужната информация за Вашата регистрация:
</legend>
<p><label>Потребителско име:
		<input type="text" name="name" size="20">
	</label></p>
<p><label>Имейл адрес:
		<input type="email" name="email" size="40">
	</label></p>
<p><label>Пол:</label>
		<input type="radio" name="gender" value="M">Мъж
		<input type="radio" name="gender" value="F">Жена
	</p>
<p><label>Възраст:
		<select name="age">
			<option value="0-29">Под 30</option>
			<option value="30-60">Между 30 и 60</option>
			<option value="60+">Над 60</option>
		</select></label></p>
<p><label>Допълнителна информация:
	<textarea name="comments" rows="3" cols="40">
	</textarea></label></p>
</fieldset>
<p align="center"><input type="submit" name="submit" value="Изпрати информацията"></p>
</form>
</body>
</html>