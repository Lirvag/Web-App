<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php
$txt="Heloo 4MI!";
$txt1="Tuk";
echo strlen($txt);
echo "<br>";
echo str_word_count($txt);
echo "<br>";
echo strrev($txt1);
echo "<br>";
echo strpos($txt,"4MI");
echo "<br>";
echo str_replace("4MI","Velislava",$txt);
echo "<br>";
$txt2="  Good  ";
echo $txt2;
echo "<br>";
echo ltrim($txt2);
echo "<br>";
echo rtrim($txt2);
echo "<br>";
echo strtolower($txt2);
echo "<br>";
echo strtoupper($txt2);
echo "<br>";
echo strpbrk($txt,"4");
echo "<br>";
echo "<span style='font: 14pt arial'>Днес е - ".date('l F - d - Y')."г..</span>";
echo "<br>";
echo "<span style='font: 12px verdana'>Текущото време е: ".date('g:i:s a').".</span>";
echo "<br>";
$x=5;
if($x<=10){
	echo "Числото е по-малко от 10!";
}
echo "<br>";
if($x<=10){
	echo"Числото е по-малко или равно от 10!";
}else{
	echo"Числото е по-голямо от 10!";
}
echo "<br>";
$t=date('H');
if($t<=10){
	echo"Добро утро!";
}elseif($t<=18){
	echo"Добър ден!";
}else{
	echo"Добър вечер!";
}
echo "<br>";
$cars="BMW";
switch($cars){
	case "Audi":echo"Любимата ми марка кола е Audi.";
	break;
	case "BMW":echo"Любимата ми марка кола е BMW.";
	break;
	case "Dacia":echo"Любимата ми марка кола е Dacia.";
	break;
	case "Ford":echo"Любимата ми марка кола е Ford.";
	break;
	case "VW":echo"Любимата ми марка кола е VW.";
	break;
	case "Opel":echo"Любимата ми марка кола е Opel.";
	break;
	case "Mazda":echo"Любимата ми марка кола е Mazda.";
	break;
	case "Nissan":echo"Любимата ми марка кола е Nissan.";
	break;
	default: echo"Любимата ми марка кола не е: Audi, BMW, Dacia, Ford, VW, Opel, Mazda, Nissan.";
}
echo "<br>";
$color="pink";
switch($color){
	case "red": echo"Любим цвят - ".$color;
	break;
	case "blue": echo"Любим цвят - ".$color;
	break;
	case "green": echo"Любим цвят - ".$color;
	break;
	case "white": echo"Любим цвят - ".$color;
	break;
	case "black": echo"Любим цвят - ".$color;
	break;
	case "gray": echo"Любим цвят - ".$color;
	break;
	default: echo"Любимият ми цвят не е бял, черен, сив, червен, син и зелен!";
}
echo "<br>";
$y=1;
while($y<=5){
	echo "Числото е: ".$y."<br>";
	$y++;
}
echo "<br>";
$z=11;
do{
	echo"Числото е: ".$z."<br>";
	$z++;
}while($z<=15);
echo "<br>";
for($i=0; $i<=7; $i++){
	echo "Стойността е - ".$i."<br>";
}
echo "<br>";
for($h=date('H');$h<=18; $h++){
	echo "Добър ден, часът е - ".$h."<br>";
}
echo "<br>";
$fcol=array("white","black","red","blue","green","pink","orange","yellow");
foreach($fcol as $value){
	echo "Цвят - ".$value."<br>";
}
echo "<br>";
$color=array("white","black","red","blue","green","pink","orange","yellow");
for($i=0;$i<sizeof($color);$i++){
	echo"елемента ",$i+1," от масива е цветът $color[$i].".'<br>';
}
$stud=array("Petq"=>"21","Ivan"=>"25","Emil"=>"31","Iva"=>"19");
foreach($stud as $key=>$value){
	echo"Студентът е на $value";
	echo "<br>";
}
echo "<br>";	
?>
</body>
</html>