<?php
//Масив с марки коли създаден в PHP
$a[]="Audi";
$a[]="BMW";
$a[]="Citroen";
$a[]="Dacia";
$a[]="Ferrari";
$a[]="Fiat";
$a[]="Ford";
$a[]="Honda";
$a[]="Hyundai";
$a[]="Infiniti";
$a[]="Jaguar";
$a[]="Jeep";
$a[]="Kia";
$a[]="Lada";
$a[]="Lancha";
$a[]="Land Rover";
$a[]="Mazda";
$a[]="Mercedes";
$a[]="Mazerati";
$a[]="Mini";
$a[]="Nissan";
$a[]="Opel";
$a[]="Peugeot";
$a[]="Renault";
$a[]="Seat";
$a[]="Subaru";
$a[]="Skoda";
$a[]="Suzuki";
$a[]="Toyota";
$a[]="VW";
$a[]="Volvo";

$q=$_REQUEST["q"];
$hint="";

if($q!==""){
	$q=strtolower($q);
	$len=strlen($q);
	
	foreach($a as $name){
		if(stristr($q,substr($name,0,$len))){
			if($hint===""){
				$hint=$name;
			}else{
				$hint.=",$name";
			}
		}
	}
}
echo $hint==="" ?"Моля, въведете валидно име на марка кола!" : $hint;
?>
