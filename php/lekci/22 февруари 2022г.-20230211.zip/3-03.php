<?php
if(isset($_FILES['image'])){
	$errors=array();
	$file_name=$_FILES['image']['name'];
	$file_size=$_FILES['image']['size'];
	$file_tmp=$_FILES['image']['tmp_name'];
	$file_type=$_FILES['image']['type'];
	$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
	
	$expensions=array("jpeg","jpg","gif","png");
	
	if(in_array($file_ext,$expensions)===false){
		$errors[]="Разширението не е разрешено. Моля изберете картинка с разширение jpeg, jpg, gif, png.";
	}
	
	if($file_size>2097152){
		$errors[]="Размерът на файла трябва да бъдо до 2МВ";
	}
	
	if(empty($errors)==true){
		move_uploaded_file($file_tmp,"images/".$file_name);
		echo "Приключи!";
	}else{
		print_r($errors);
	}
}
echo "Файлът е прикачен!";
?>
