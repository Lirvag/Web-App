<HTML>
<head>
<title>PHP формуляр</title>
</head>
<body>
<!--PHP регистрация чрез абсолютни класове-->
<?php
//дефинаране на променливи и задаване на празна стойност
$nikname=$email=$datta=$comment=$passw=$gender="";

if($_SERVER["REQUEST_METHOD"]=="POST"){
	$nikname=test_input($_POST["name"]);
	$email=test_input($_POST["email"]);
	$datta=test_input($_POST["datta"]);
	$comment=test_input($_POST["comment"]);
	$passw=test_input($_POST["passw"]);
	$gender=test_input($_POST["gender"]);
}

function test_input($data){
	$data=trim($data);
	$data=stripslashes($data);
	$data=htmlspecialchars($data);
	return $data;
}
?>
<h2>PHP регистрация чрез абсолютни класове</h2>
<form method="post" action="04-1.php">
<table>
<tr>
<td>Потребителско име:</td>
<td><input type="text" name="name"></td>
</tr>
<tr>
<td>Парола:</td>
<td><input type="password" name="passw"></td>
</tr>
<tr>
<td>E-mail:</td>
<td><input type="text" name="email"></td>
</tr>
<tr>
<td>Дата на регистрация:</td>
<td><input type="date" name="datta"></td>
</tr>
<tr>
<td>Информация:</td>
<td><textarea name="comment" rows="5" cols="40"></textarea></td>
</tr>
<tr>
<td>Пол:</td>
<td><input type="radio" name="gender" value="female">Жена<br>
	<input type="radio" name="gender" value="male">Мъж
</td>
</tr>
</table>
<input type="submit" name="submit" value="ИЗПРАТИ">
</form>
<?php
echo "<h2>Въведените данни във формуляра са както следва:</h2>";
echo $nikname;
echo "<br>";
echo $passw;
echo "<br>";
echo $email;
echo "<br>";
echo $datta;
echo "<br>";
echo $comment;
echo "<br>";
echo $gender;
?>
</body>
</html>
