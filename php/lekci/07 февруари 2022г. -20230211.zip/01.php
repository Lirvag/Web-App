<!DOCTYPE html>
<html>
<body>
<h1>Моята първа PHP страница!</h1>
<p>
<?php
echo "Здравейте 3КИ и 4МИ!";
$myvar="3KI&4MI";
echo "<br>";
echo $myvar;
echo "<br>";
ECHO $myvar;
echo "<br>";
Echo $myvar;
echo "<br>";
$x=5;
$y=4;
echo $x+$y;
echo "<br>";
function myTest(){
	echo "Променливата х вътрешна стойност за фукция $x";
}
myTest();
echo "<br>";
echo "Променливата х е външна стойност за функцията $x";
echo "<br>";
function myTest1(){
	global $x,$y;
	$y=$y+$x;
}
myTest1();
echo $y;
echo "<br>";
function myTest2(){
	static $x=0;
	echo $x;
	$x++;
}
myTest2();
echo "<br>";
myTest2();
echo "<br>";
myTest2();
echo "<br>";
$n=5798;
var_dump($n);
echo "<br>";
$m=11.258;
var_dump($m);
echo "<br>";
$tа=array("red","blue","green","black","white");
var_dump($tа);
echo "<br>";
$a="3КИ";
$b="4МИ";
echo "Добър ден ".$a." и ".$b."!";
echo "<br>";
$p=11.5;
$t=2.25;
$total=$p*$t;
echo $total;
echo "<br>";
echo "$".sprintf("%01.2f",$total);
echo "<br>";
echo "Първата стойност на месива е - ".$tа[0]."<br>";
echo "Втората стойност на месива е - ".$tа[1]."<br>";
echo "Третата стойност на месива е - ".$tа[2]."<br>";
echo "Четвъртата стойност на месива е - ".$tа[3]."<br>";
echo "Петата стойност на месива е - ".$tа[4]."<br>";
echo "<br>";
$stud=array('Fname'=>'Ана','Lname'=>'Пеева','Age'=>33);
echo "Собствено име: ".$stud['Fname'];
echo "  Фамилно име: ".$stud['Lname'];
echo "  Възраст: ".$stud['Age'];
echo "<br>";
define("GREETING", "Добре дошли!!!");
echo GREETING;
echo "<br>";
define("int_cost",500);
echo int_cost;
echo "<br>";
define("flo_cost",1.25);
echo flo_cost;
echo "<br>";
echo flo_cost+int_cost;
echo "<br>";
?>
</p>
</body>
</html>
