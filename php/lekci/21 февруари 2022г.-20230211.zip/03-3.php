<!DOCTYPE html>
<html>
<body>
<form action="3-03.php" method="post">
Изберете картинка за качване:
<input type="file" name="image" id="fileToUpload">
<input type="submit" name="UploadImage" value="ПРИКАЧИ">
</form>
</body>
</html>
