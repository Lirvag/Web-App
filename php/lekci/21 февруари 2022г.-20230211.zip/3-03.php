<?php
if(isset($_SERVER['image'])){
	$errors=array();
	$file_name=$_SERVER['image']['name'];
	$file_size=$_SERVER['image']['size'];
	$file_tmp=$_SERVER['image']['tmp_name'];
	$file_type=$_SERVER['image']['type'];
	$file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
	
	$expensions=array("jpeg","jpg","gif","png");
	
	if(in_array($file_ext,$expensions)===false){
		$errors[]="Разширението не е разрешено. Моля изберете картинка с разширение jpeg, jpg, gif, png.";
	}
	
	