<html>
<body>
Добре дошъл
<?php
echo $_POST["fname"];
echo " ".$_POST["lname"];
?>
<br>
</body>
</html>