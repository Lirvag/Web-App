<!DOCTYPE html>
<html>
<body>
<?php
$cars=array("BMW","VW","Opel","Mini");
echo count($cars);
echo "<br>";
rsort($cars);
$arrlen=count($cars);
for($i=0; $i<$arrlen; $i++){
	echo $cars[$i];
	echo "<br>";
}
$age=array("Peter"=>"33","Iva"=>"22","Ema"=>"19");
echo "Peter e na ".$age['Peter']." godini.";
echo "<br>";
krsort($age);
foreach($age as $x=>$x_value){
	echo "Ime - ".$x." Vyzrast - ".$x_value;
	echo "<br>";
}

?>
</body>
</html>