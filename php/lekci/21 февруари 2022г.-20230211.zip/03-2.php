<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Numbers</title>
</head>
<body>
<?php
$quantity=30;
$price=119.95;
$taxrate=0.05;
$total=$quantity*$price;
$total=$total+($total*$taxrate);
$total=number_format($total,2);
echo '<p>Вие купувате <strong>'.$quantity.'</strong> 
	продукта (ти) на цена от <strong>'.$price.' $</strong>
	 всеки. Общата Ви сума с добавения данък е 
		<strong><big>'.$total.' $</strong></big>.</p>';
?>
</body>
</html>

	 