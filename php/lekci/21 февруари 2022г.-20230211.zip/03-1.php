<!DOCTYPE html>
<html>
<body>
<form method="post" action="1-03.php">
Собствено име:
<input type="text" name="fname">
<br>
Фамилно име:
<input type="text" name="lname">
<br>
<input type="submit" name="submit" value="ИЗПРАТИ">
</form>
<?php
if($_SERVER["REQUEST_METHOD"=="POST"]){
	$name=$_POST['fname'];
	if(empty($name)){
		echo "Името е празно!!!";
	}else{
		echo $name;
	}
	$lname=$_POST['lname'];
	if(empty($lname)){
		echo "Фамилията е празна!!!";
	}else{
		echo $lname;
	}
}
echo $_SERVER['PHP_SELF'];
echo "<br>";
echo $_SERVER['SERVER_ADDR'];
echo "<br>";
echo $_SERVER['SERVER_NAME'];
echo "<br>";
?>
</body>
</html>