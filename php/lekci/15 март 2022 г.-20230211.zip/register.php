<?php
$page_title='Регистрация';
include('header.html');
?>
<h1>Регистрационна форма</h1>
<form method="post" action="register.php">
<p>Собствено име:
	<input type="text" name="fname" size="15" maxlength="20" value="<?php
			if(isset($_POST['fname'])) echo $_POST['fname']; ?>" >
</p>

<p>Фамилно име:
	<input type="text" name="lname" size="15" maxlength="40" value="<?php
			if(isset($_POST['lname'])) echo $_POST['lname']; ?>" >
</p>

<p>Имейл адрес:
	<input type="email" name="email" size="20" maxlength="60" value="<?php
			if(isset($_POST['email'])) echo $_POST['email']; ?>" >
</p>

<p>Парола:
	<input type="password" name="pass" size="10" maxlength="20" value="<?php
			if(isset($_POST['pass'])) echo $_POST['pass']; ?> " >
</p>

<p><input type="submit" name="submit" value="РЕГИСТРИРАЙ"></p>
</form>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
	$errors=[];
	
	if(empty($_POST['fname'])){
		$errors[]='Забравихте да въведете собственото име!';
	}else{
		$f=trim($_POST['fname']);
	}
	
	if(empty($_POST['lname'])){
		$errors[]='Забравихте да въведете фамилното име!';
	}else{
		$l=trim($_POST['lname']);
	}
	
	if(empty($_POST['email'])){
		$errors[]='Забравихте да въведете имейл адреса си!';
	}else{
		$e=trim($_POST['email']);
	}
	
	if(empty($_POST['pass'])){
		$errors[]='Забравихте да въведете паролата си!';
	}else{
		$p=trim($_POST['pass']);
	}
	
	if(empty($errors)){
		require('mysqli_connect.php');
		$q="INSERT INTO users(fname,lname,email,pass,regdate) VALUE 
				('$f','$l','$e','$p',NOW())";
		$r=@mysqli_query($dbc,$q);
		if($r){
			echo '<h1>Благодаря!</h1>
				<p>Вие успешно се регистрирахте!</p>';
		}else{
			echo '<h1>Системна грешка!</h1>
				<p class="error">Не можахте да бъдете регистриран поради системна
				грешка. Извинявайте за неудобството!</p>';
			echo '<p>' .mysqli_error($dbc). '<br><br> Query:' .$q. '</p>';
		}
		mysqli_close($dbc);
		include('footer.html');
		exit();
	}else{
		echo '<h1>Грешка!</h1>
			<p class="error">Възникна следната грешка:<br>';
			foreach($errors as $msg){
				echo " - $msg <br> \n";
			}
		echo '</p>
			<p>Моля опитайте отново да се регистрирате!</p>';
	}
}
include('footer.html');
?>
	
	
	
	
	
	
	
	
	
	