<?php
$dbc=@mysqli_connect('localhost','MIKI','123miki','musers') OR die('Could not 
	connect to MySQL:' .mysqli_connect_error());
mysqli_set_charset($dbc,'utf-8');