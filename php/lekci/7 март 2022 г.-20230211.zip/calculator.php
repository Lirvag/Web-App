<?php
$page_title="Калкулатор на разходите за пътуване";
include('header.html');
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['distance'],$_POST['price'],$_POST['efficiency']) && 
		is_numeric($_POST['distance']) && is_numeric($_POST['price']) &&
		is_numeric($_POST['efficiency'])){
	$gallons=$_POST['distance']/$_POST['efficiency'];
	$dollars=$gallons*$_POST['price'];
	$hours=$_POST['distance']/75;
	echo '<div class="page-header">
			<h1>Общи прогнозни разходи</h1>
		</div>
		<p>Общата цена за шофирането на '.$_POST['distance'].' километра и усредната '
		.$_POST['efficiency'].' км на литър гориво, както и средната цена $'.
		$_POST['price'].' за литър гориво е $ '.number_format($dollars,2).'. Ако шофирате
		средно 75 км за час, пътуването ще ви отнеме приблизително '.
		number_format($hours,2).' часа.</p>';
		}
}
?>
<div class="page-header">
	<h1>Калкулатор на разходите за пътуване</h1>
</div>
<form action="calculator.php" method="post">

<p>Разстояние (в км):
	<input type="number" name="distance">
</p>

<p>Средна цена за литър гориво:
	<input type="radio" name="price" value="2.50">2.50
	<input type="radio" name="price" value="3.00">3.00
	<input type="radio" name="price" value="3.50">3.50
</p>

<p>Ефективност на шофирането (гориво):
	<select name="efficiency">
		<option value="10">Ужасно</option>
		<option value="20">Прилично</option>
		<option value="30">Много добро</option>
		<option value="50">Изключително</option>
	</select>
</p>

<p><input type="submit" name="submit" value="ИЗЧИСЛИ!"></p>

</form>

<?php
include('footer.html');
?>