<?php
function create_price_radio($value){
	echo '<input type="radio" name="price" value="'.$value.'"';
	if(isset($_POST['price']) && ($_POST['price']==$value)){
	echo 'checked="checked"';}
	echo ">$value";
}

function create_radio($value,$name){
	echo '<input type="radio" name="'.$name.'" value="'.$value.'"';
	if(isset($_POST[$name]) && ($_POST[$name]==$value)){
	echo 'checked="checked"';}
	echo ">$value";
}

function calculate_trip_cost($km,$mpg,$ppg){
	$gallons=$km/$mpg;
	$dollars=$gallons*$ppg;
	return number_format($dollars,2);
}

$page_title="Калкулатор1";
include('header.html');
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['distance'],$_POST['price'],$_POST['efficiency']) && 
		is_numeric($_POST['distance']) && is_numeric($_POST['price']) &&
		is_numeric($_POST['efficiency'])){
	$cost=calculate_trip_cost($_POST['distance'],$_POST['efficiency'],$_POST['price']);
	$hours=$_POST['distance']/75;
	echo '<div class="page-header">
			<h1>Общи прогнозни разходи</h1>
		</div>
		<p>Общата цена за шофирането на '.$_POST['distance'].' километра и усредната '
		.$_POST['efficiency'].' км на литър гориво, както и средната цена $'.
		$_POST['price'].' за литър гориво е $ '.$cost.'. Ако шофирате
		средно 75 км за час, пътуването ще ви отнеме приблизително '.
		number_format($hours,2).' часа.</p>';
		}else{
			echo '<div class="page-header">
		<h1>Грешка!</h1></div>';}
}
?>
<div class="page-header">
	<h1>Калкулатор на разходите за пътуване</h1>
</div>
<form action="calculator.php" method="post">

<p>Разстояние (в км):
	<input type="number" name="distance" value="<?php
			if(isset($_POST['distance']))
				echo $_POST['distance'];?>" >
</p>

<p>Средна цена за литър гориво:
<!--
< ?php
	create_price_radio('2.50');
	create_price_radio('3.00');
	create_price_radio('3.50');
?>
-->
<?php
	create_radio('2.50','price');
	create_radio('3.00','price');
	create_radio('3.50','price');
?>
</p>

<p>Ефективност на шофирането (гориво):
	<select name="efficiency">
		<option value="10" <?php
			if(isset($_POST['efficiecy']) && ($_POST['efficiecy']=='10'))
				echo 'selected="selected"';?> >Ужасно</option>
		<option value="20" <?php
			if(isset($_POST['efficiecy']) && ($_POST['efficiecy']=='20'))
				echo 'selected="selected"';?> >Прилично</option>
		<option value="30" <?php
			if(isset($_POST['efficiecy']) && ($_POST['efficiecy']=='30'))
				echo 'selected="selected"';?> >Много добро</option>
		<option value="50" <?php
			if(isset($_POST['efficiecy']) && ($_POST['efficiecy']=='50'))
				echo 'selected="selected"';?> >Изключително</option>
	</select>
</p>

<p><input type="submit" name="submit" value="ИЗЧИСЛИ!"></p>

</form>

<?php
include('footer.html');
?>