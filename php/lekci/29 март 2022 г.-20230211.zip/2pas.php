<!DOCTYPE html>
<html>
<body>
<?php
$page_title='Информация за потребител';
include('header.html');
echo '<h1>Информация за регистриран потребител:</h1>';
require('mysqli_connect.php');
if($dbc->connect_error){
	die("Connection failed: ".$dbc->connect_error);
}
$e=$_POST['email'];
$p=$_POST['pass'];
$q = "SELECT `user_id`,`fname`,`lname`,`email` FROM `users` 
		WHERE `email`='$e' and `pass`='$p'";
$r=$dbc->query($q);
	if($r->num_rows>0){
		while($row=$r->fetch_assoc()){
			echo "<br> id: ".$row["user_id"]."  -  Име и Фамилия: ".$row["fname"].
		"  ".$row["lname"]."   - Email Address: ".$row["email"]."<br><br>";
		}
	}else{
		echo "0 регистрирани потребители!";
	}
$dbc->close();
?>
<form method="post" action="3pas.php">
User_ID:<input type="number" name="user_id"><br>
Нова потребителска парола:<input type="password" name="pass1"><br>
<input type="submit" name="submit" value="ПРОМЕНИ">
</form>
<?php
include('footer.html');
?>
</body>
</html>