<?php
$page_title='Потребители';
include('header.html');
echo '<h1>Регистрирани потребители:</h1>';
require('mysqli_connect.php');
$q = "SELECT `fname`,`lname`,`email`,`regdate` FROM `users` ORDER BY `fname` ASC";
$r=@mysqli_query($dbc,$q);
if($r){
	echo '<table width="60%">
		<thead>
		<tr>
		<th align="left">Собствено име</th>
		<th align="left">Фамилно име</th>
		<th align="left">Имейл адрес</th>
		<th align="left">Дата на регистрация</th>
		</tr>
		</thead>
		<tbody>';
		while($row=mysqli_fetch_array($r,MYSQLI_ASSOC)){
				echo '<tr>
						<td align="left">'.$row['fname'].'</td>
						<td align="left">'.$row['lname'].'</td>
						<td align="left">'.$row['email'].'</td>
						<td align="left">'.$row['regdate'].'</td>
					</tr>';
		}
		echo '</tbody>
			</table>';
		mysqli_free_result($r);
}else{
	echo '<p class="error">Текущите потребители не могат да бъдат извлечени. 
	Извиняваме се за неудобството!</p>';
	echo '<p>'.mysqli_error($dbc).'<br><br> Заявка: '.$q.'</p>';
}
mysqli_close($dbc);
include('footer.html');
?>