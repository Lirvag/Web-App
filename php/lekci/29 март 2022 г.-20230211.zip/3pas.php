<?php
$page_title='Промяна на парола';
include('header.html');
echo '<h1>Информация за потребителя:</h1>';
require('mysqli_connect.php');
if($dbc->connect_error){
	die("Connection failed: ".$dbc->connect_error);
}
$id=$_POST['user_id'];
$p1=$_POST['pass1'];
$q = "UPDATE `users` SET `pass`='$p1' WHERE `user_id`='$id'";
if($dbc->query($q)===TRUE){
	echo 'Паролата успешно е променена!';
}else{
	echo 'Възникна грешка при актуализацията на паролата: '.$dbc->error;
}
$dbc->close();
include('footer.html');
?>