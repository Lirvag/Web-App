<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body>
<?php
$page_title='Входни данни';
include('header.html');
?>
<h1>Входна информация за потребител:</h1>
<form method="post" action="2pas.php">
Имейл адрес:<input type="email" name="email"><br>
Парола:<input type="password" name="pass"><br>
<input type="submit" name="submit" value="НАТИСНИ">
</form>
<?php
include('footer.html');
?>
</body>
</html>