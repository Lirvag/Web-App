<!DOCTYPE html>
<html>
<body>
<h1>Моята страничка</h1>
<p>
<?php
$x=5;
function myTest(){
	$x=6;
echo "Promenlivata x e wynshna za funkciqta: $x";
}
myTest();
echo "<p>Promenlivata x e vytreshna za funkciqta: $x </p>";
function myTest1(){
	global $x;
	$y=10;
	$z=$x+$y;
	echo $z;
	$a="Page";
	$b='Pages';
	echo $a;
	echo "<br>";
	echo $b;
		echo "<br>";
	$p=5987;
	var_dump($p);
	echo "<br>";
		$o=10.359;
	var_dump($o);
	echo "<br>";
	$cars=array("BMW","VW","Opel");
	var_dump($cars);
	echo"<br>";
	$x=null;
	var_dump($x);
	echo"<br>";
	echo "Namirame se na 1 ".$a." ot obshtiq broj 10 ".$b;
	echo "<br>";
	$tax=1.2;
	echo "$".sprintf("%01.2f",$p*$tax);
	echo"<br>";
}
myTest1();


?>
</body>
</html>