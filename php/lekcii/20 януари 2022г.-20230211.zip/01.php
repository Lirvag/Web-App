<!DOCTYPE html>
<html>
<body>
<h1>Моята страничка</h1>
<p>
<?php
echo "Hello 3KI!";
?>
</p>
<?php 
$x=5/*+15*/+5;
echo $x;
echo "<br>";
$txt="Da pisha PHP pages!";
echo "I love $txt!";
echo"<br>";
$y=11;
echo $x+$y;
echo"<br>";
function myTest(){
	echo "Promenlivata x e vytreshna za funkciqta: $x";
}
myTest();











?>
</body>
</html>
