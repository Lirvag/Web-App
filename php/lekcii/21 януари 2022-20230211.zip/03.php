<!DOCTYPE html>
<html>
<body>
<?php
$my_masiv=array('red','blue','green','orange');
echo "Първата стойност на масива е - ".$my_masiv[0].".<br>";
echo "Втората стойност на масива е - ".$my_masiv[1].".<br>";
echo "Третата стойност на масива е - ".$my_masiv[2].".<br>";
echo "Четвъртата стойност на масива е - ".$my_masiv[3].".<br>";
$men=array('FName'=>'Ivan','LName'=>'Tomov','Age'=>37);
echo "Собственото име е: ".$men['FName'];
echo "<br>Фамилното име е: ".$men['LName'];
echo"<br> Възрастта е: ".$men['Age'];
echo "<br>";
$number=array(50,20,18,30,79);
$array_size=sizeof($number);
echo "<br>";
echo $array_size;
echo "<br>";
$one=array_slice($number,2,1);
define("STRINGs","PHP program");
echo STRINGs;
echo "<br>";
$name="Eva";
echo "Imeto na potrebitelq e \\ $name.\n Lubimiqt mu cvqt e:" .$my_masiv[2];
echo "<br>";
?>



</body>
</html>