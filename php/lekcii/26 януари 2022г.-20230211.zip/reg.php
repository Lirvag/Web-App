<!DOCTYPE html>
<html>
<head>
<style>
	.error {color: #FF0000;}
</style>
<title>Регистрация чрез абсолютни класове</title>
</head>
<body>
<?php
$nameErr=$emailErr=$genderErr=$websiteErr="";
$name=$email=$gender=$comment=$website="";
if($_SERVER["REQUEST_METHOD"]=="POST"){
	if(empty($_POST["name"])){
		$nameErr="Името е задължително!!!";
	} else {
		$name=test_input($_POST["name"]);
	}
	
	if(empty($_POST["email"])){
		$emailErr="Имейла е задължителен!!!";
	} else {
		$email=test_input($_POST["email"]);
		//проверяваме дали имейла е добре оформен
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			$emailErr="Невалиден имейл формат!";
		}
	}
	
	if(empty($_POST["website"])){
		$website="";
	} else {
		$website=test_input($_POST["website"]);
	}
	
	if (empty($_POST["comment"])){
		$comment="";
	} else {
		$comment=test_input($_POST["comment"]);
	}
	
	if (empty($_POST["gender"])){
		$genderErr="Изисква се да въведете пол!";
	} else {
		$gender=test_input($_POST["gender"]);
	}
}

function test_input($data){
	$data=trim($data);
	$data=stripcslashes($data);
	$data=htmlspecialchars($data);
	return $data;
}
?>
<h2>Абсолютна регистрация на класове</h2>
<p> <span class="error">*задължително поле</span></p>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
<table>
<tr>
<td> ИМЕ:</td>
<td><input type="text" name="name">
	<span class="error">*<?php echo $nameErr; ?> </span>
</td>
</tr>

<tr>
<td> E-MAIL:</td>
<td><input type="text" name="email">
	<span class="error">*<?php echo $emailErr; ?> </span>
</td>
</tr>	
	
<tr>
<td> САЙТ:</td>
<td><input type="text" name="website">
	<span class="error">*<?php echo $websiteErr; ?> </span>
</td>
</tr>	
	
<tr>
<td> ИНФОРМАЦИЯ:</td>
<td><textarea name="comment" rows="5" cols="40"></textarea>
</td>
</tr>	

<tr>
<td> ПОЛ:</td>
<td><input type="radio" name="gender" value="female">жена
	<input type="radio" name="gender" value="male">мъж
	<span class="error">*<?php echo $nameErr; ?> </span>
</td>
</tr>
		
<td>
	<input type="submit" name="submit" value="ИЗПРАТИ">
</td>
</table>
</form>

<?php
echo "<h2>Въведените проверени данни са както следва:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $website;
echo "<br>";
echo $comment;
echo "<br>";
echo $gender;
?>

</body>
</html>







			
			
		
		
		
		
		
		