<!DOCTYPE html>
<html>
<body>
<?php
$cars=array("VW","BMW","Audi","Opel");
rsort($cars);
$len=count($cars);
for ($x=0;$x<$len;$x++){
	echo $cars[$x];
	echo "<br>";
}
$age=array("Peter"=>"35","Ivan"=>"37","Ana"=>"43");
ksort($age);
foreach($age as $x=>$x_value){
	echo "key= ".$x. ", Value = ".$x_value;
	echo "<br>";
}
$myfile=fopen("webname.txt","r")or die("Unable to open file!");
echo fread($myfile,filesize("webname.txt"));
//fclose($myfile);
echo "<br>";
while(!feof($myfile)){
	echo fgetc($myfile);
}
fclose($myfile);

?>
</body>
</html>