<!DOCTYPE html>
<html>
<body>
<form method="post" action="1.php">
ИМЕ: <input type="text" name="name">
<input type="submit" name="ИЗПРАТИ">
</form>
<?php
$ime=$_POST["name"];
if (empty($ime)){
	echo "Името е празно!";
} else {
	echo $ime;
}
function writeMsg(){
	echo "Здравейте, вие сте нов потребител!";
}
writeMsg();
function familyName($fname){
	echo "$fname <br>";
}
familyName("Iva");
familyName("Boris");
familyName("Ana");
function sum($x,$y){
	$z=$x+$y;
	return $z;
}
echo "5 + 10 = ".sum(5,10)."<br>";
echo "7 + 13 = ".sum(7,13)."<br>";




?>
</body>
</html>
