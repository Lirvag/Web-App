<html>
<body>
Добре дошъл 
<?php
echo $_POST["name"];
?>
<br>
</body>
</html>
