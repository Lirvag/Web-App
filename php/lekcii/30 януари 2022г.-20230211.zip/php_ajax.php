<?php
//Масив за марки автомобили
$a[]="AUDI";
$a[]="BMW";
$a[]="Citroen";
$a[]="Dachia";
$a[]="Ferrari";
$a[]="Ford";
$a[]="Honda";
$a[]="Peugeot";
$a[]="Mercedes";
$a[]="Infiniti";
$a[]="Jeep";
$a[]="Kia";
$a[]="Lada";
$a[]="Land Rover";
$a[]="Mazda";
$a[]="Mini";
$a[]="Nissan";
$a[]="Suzuki";
$a[]="Opel";
$a[]="Porsche";
$a[]="Toyota";
$a[]="VW";
$a[]="Volvo";
$a[]="Subaru";

$q=$_REQUEST["q"];
$hint="";

if($q !==""){
	$q=strtolower($q);
	$len=strlen($q);
	foreach($a as $name){
		if(stristr($q,substr($name,0, $len))){
			if($hint ===""){
				$hint=$name;
			} else {
				$hint.=",$name";
			}
		}
	}
}
echo $hint ===""?"Моля, въведете валидно име на марка кола!": $hint;
?>
