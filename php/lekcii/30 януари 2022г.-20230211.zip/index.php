<?php
include("head.php");
	echo '<h1>Моят първи PHP проект!</h1>';
	echo "Добре дошли в моят проект!";
include("foot.php");
?>
