<!DOCTYPE html>
<html>
<body>
<?php
$text="Hello PHP world!";
echo $text;
echo "<br>";
echo strlen($text);
echo "<br>";
echo str_word_count($text);
echo "<br>";
echo strrev($text);
echo "<br>";
echo strpos($text,"PHP");
echo "<br>";
echo str_replace("world","pages",$text);
echo "<br>";
echo "<span style='font: 10px arial'>Днес е: ".date('l F d Y')."</span>";
echo "<br>";
echo "<span style='font: 10px arial'>Текущото време е: ".date('g:i:s a')."</span>";
echo "<br>";
$t=date('H');
if($t<'20'){
	echo "Добър ден!";
} else {
	echo "Добър вечер!";
}
echo "<br>";
$ta='21';
if($ta<='9'){
	echo "Добро утро!";
}elseif($ta<='20'){
	echo "Добър ден!";
} else {
	echo "Добър вечер!";
}
echo "<br>";
$fcolor="blue";
switch($fcolor){
	case "red":
		echo "Любимия ти цвят е червен.";
		break;
	case "blue":
		echo "Любимия ти цвят е син.";
		break;
	case "green":
		echo "Любимия ти цвят е зелен.";
		break;
	default:
		echo "Любимия ти цвят не е червен, син или зелен.";
}
echo "<br>";
$x=6;
while($x<=5){
	echo"Числото е: $x <br>";
	$x++;
}
echo "hhh<br>";
$y=6;
do{
	echo"Числото е: $y <br>";
	$y++;
}while($y<=5);
echo "<br>";
for($i=0;$i<=10;$i++){
	echo "Числото е: $i <br>";
}
echo"<br>";
$colors=array("red","blue","green","yellow","orange","pink");
foreach($colors as $value){
	echo "Цветът е: $value .<br>";
}
echo"<br>";
$age=array("Petq"=>"25","Ana"=>"19","Iva"=>"21");
foreach($age as $key=>$value){
	echo "Възрастта на студента е: $value.<br>";
}
echo"<br>";
?>
</body>
</html>