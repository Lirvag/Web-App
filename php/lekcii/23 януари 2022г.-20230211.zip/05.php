<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> Calendar</title>
</head>
<body>
<form action="calendar.php" method="post">
<?php
$month=[1=>'Януари','Февруари','Март','Април','Май','Юни','Юли','Август','Септември','Октомври','Ноември','Декември'];
echo '<select name="month">';
foreach($month as $key=>$value){
	echo "<option value=\"key\">$value</option>\n";
}
echo '</select>';
echo '<select name="day">';
for($day=1; $day<=31; $day++){
	echo "<option value=\"$day\">$day </option>\n";
}
echo '</select>';
echo '<select name="year">';
for ($year=2000; $year<=2050; $year++){
	echo "<option value=\"$year\">$year</option>\n";
}
echo '</select>';
?>
</body>
</html>